from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.admin_login, name='login'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('loanplan/', views.loanplan, name='loanplan'),
    path('calculator/', views.calculator, name='calculator'),
    path('contact/', views.contact, name='contact'),
    path('apply/', views.apply, name='apply'),
    path('apply2/', views.apply2, name='apply2'),
    path('review/', views.review, name='review'),
    path('admin/add-customer/', views.add_customer, name='add_customer'),
    path('dashboard/customers/', views.customer_list, name='customer_list'),
    path('dashboard/customers/delete/<int:pk>/', views.delete_customer, name='delete_customer'),
    path('dashboard/customers/add/', views.add_customer, name='add_customer'),
    path('logout/', views.logout_view, name='logout'),
     path('reviews/', views.review_list, name='review_list'),
    
]
